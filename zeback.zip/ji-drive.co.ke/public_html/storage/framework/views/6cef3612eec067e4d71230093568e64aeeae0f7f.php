<div class="alert alert-<?php echo e($type); ?>"><?php echo balanceTags($message); ?></div>
<?php /**PATH /home/admin/web/ji-drive.com/public_html/app/Views/common/alert.blade.php ENDPATH**/ ?>
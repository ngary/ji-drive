<?php
if (!isset($cart)) {
    return;
}

$serviceID = $cart['serviceID'];
$serviceObject = unserialize($cart['serviceObject']);
?>
<h3 class="heading"><?php echo e(__('Your Item')); ?></h3>
<div class="card-box mt-3 cart-information cart-experience-item">
    <div class="media service-detail d-flex align-items-start">
        <?php
        $thumbnail = get_attachment_url($serviceObject->thumbnail_id, [400, 400])
        ?>
        <img src="<?php echo e($thumbnail); ?>" class="mr-3"
             alt="<?php echo e(get_attachment_alt($serviceObject->thumbnail_id)); ?>">
        <div class="media-body">
            <a target="_blank"
               href="<?php echo e(get_car_permalink($serviceID, $serviceObject->post_slug)); ?>"><?php echo e(get_translate($serviceObject->post_title)); ?></a>
            <?php if($address = get_translate($serviceObject->location_address)): ?>
                <div class="desc mt-2">
                    <i class="fe-map-pin mr-1"></i> <?php echo e($address); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <h5 class="title"><?php echo e(__('Detail')); ?></h5>
    <ul class="menu cart-list">
        <?php
        $startDateTime = $cart['cartData']['startDateTime'];
        $endDateTime = $cart['cartData']['endDateTime'];
        $number = $cart['cartData']['number'];
        ?>
        <li>
            <span><?php echo e(__('From')); ?></span>
            <span>
                <?php echo e(date(hh_date_format(true), $startDateTime)); ?>

            </span>
        </li>
        <li>
            <span><?php echo e(__('To')); ?></span>
            <span>
                <?php echo e(date(hh_date_format(true), $endDateTime)); ?>

            </span>
        </li>
        <li>
            <span><?php echo e(__('Number')); ?></span>
            <span>
                <?php echo e($number); ?>

            </span>
        </li>
    </ul>
    <?php
    $coupon = isset($cart['cartData']['coupon']) ? $cart['cartData']['coupon'] : [];
    $couponCode = isset($coupon->coupon_code) ? $coupon->coupon_code : '';
    ?>
    <form action="<?php echo e(url('add-coupon')); ?>" class="form-sm form-action form-add-coupon"
          data-validation-id="form-add-coupon"
          method="post"
          data-reload-time="1000">
        <?php echo $__env->make('common.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="form-group">
            <label for="coupon"><?php echo e(__('Coupon Code')); ?></label>
            <input id="coupon" type="text" class="form-control" name="coupon"
                   value="<?php echo e($couponCode); ?>"
                   placeholder="<?php echo e(__('Have a coupon?')); ?>">
            <input type="hidden" name="service_id"
                   value="<?php echo e($serviceID); ?>">
            <input type="hidden" name="service_type"
                   value="car">
            <button class="btn" type="submit" name="sm"><i class="fe-arrow-right "></i>
            </button>
        </div>
        <div class="form-message"></div>
    </form>
    <h5 class="title"><?php echo e(__('Summary')); ?></h5>
    <ul class="menu cart-list">
        <?php
        $equipment_price = $cart['equipmentPrice'];
        $insurance_price = $cart['insurancePrice'];
        $tax = $cart['tax'];
        ?>
        <li>
            <span><?php echo e(__('Car Rental Price')); ?></span>
            <span><?php echo e(convert_price($cart['basePrice'])); ?></span>
        </li>
        <?php if($equipment_price > 0): ?>
            <li>
                <span><?php echo e(__('Equipment Price')); ?></span>
                <span><?php echo e(convert_price($equipment_price)); ?></span>
            </li>
        <?php endif; ?>
        <?php if($insurance_price > 0): ?>
            <li>
                <span><?php echo e(__('Insurance Price')); ?></span>
                <span><?php echo e(convert_price($insurance_price)); ?></span>
            </li>
        <?php endif; ?>
        <?php if(!empty($coupon)): ?>
            <li>
                <form action="<?php echo e(url('remove-coupon')); ?>" class="form-action" method="post"
                      data-validation-id="form-remove-coupon"
                      data-reload-time="1500">
                    <?php echo $__env->make('common.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <input type="hidden" name="carID"
                           value="<?php echo e($serviceID); ?>">
                    <div class="d-flex align-items-center">
                        <span>
                            <?php echo e(__('Coupon')); ?>

                            <button class="btn ml-2" type="submit" name="sm"><?php echo e(__('(remove)')); ?></button>
                        </span>
                        <span>- <?php echo e($coupon->couponPriceHtml); ?></span>
                    </div>
                    <div class="form-message"></div>
                </form>
            </li>
        <?php endif; ?>
        <li>
            <span><?php echo e(__('Sub Total')); ?></span>
            <span><?php echo e(convert_price($cart['subTotal'])); ?></span>
        </li>
        <?php
        $tax_value = (float)$cart['tax']['tax'];
        if($tax_value > 0){
        ?>
        <li class="divider pt-2">
            <span><?php echo e(__('Tax')); ?>

                <span class="text-muted">
                    <?php if($cart['tax']['included'] == 'on'): ?>
                        <?php echo e(__('(included)')); ?>

                    <?php endif; ?>
                </span>
            </span>
            <span><?php echo e($tax_value); ?>%</span>
        </li>
        <?php } ?>
        <li class="amount">
            <span><?php echo e(__('Amount')); ?></span>
            <span><?php echo e(convert_price($cart['amount'])); ?></span>
        </li>
    </ul>
</div>
<?php /**PATH /home/admin/web/ji-drive.co.ke/public_html/app/Views/frontend/car/cart-item.blade.php ENDPATH**/ ?>
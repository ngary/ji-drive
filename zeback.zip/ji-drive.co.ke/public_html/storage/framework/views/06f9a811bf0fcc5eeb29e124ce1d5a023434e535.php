<?php echo $__env->make('dashboard.components.right-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php do_action('footer'); ?>
<?php do_action('init_footer'); ?>
<?php do_action('init_dashboard_footer'); ?>
<script src="<?php echo e(asset('js/option.js')); ?>"></script>
<script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/admin/web/ji-drive.com/public_html/app/Views/dashboard/components/footer.blade.php ENDPATH**/ ?>
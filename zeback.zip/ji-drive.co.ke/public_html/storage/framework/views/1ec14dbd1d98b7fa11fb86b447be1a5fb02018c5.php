<div class="total-render d-flex align-items-center">
    <h5><?php echo e(__('Total')); ?></h5>
    <div class="price-wrapper ml-auto">
        <span class="price"><?php echo balanceTags(convert_price($total)); ?></span>
    </div>
</div>
<?php /**PATH /var/www/bookings/html/app/Views/frontend/car/calculate-price-render.blade.php ENDPATH**/ ?>
<?php
$booking_type = get_car_booking_type();
?>
<h1 class="h3"><?php echo e(__('Search for Cheap Rental Cars')); ?></h1>
<form action="<?php echo e(get_car_search_page()); ?>" class="form mt-3" method="get">
    <div class="form-group">
        <label><?php echo e(__('Where')); ?></label>
        <div class="form-control" data-plugin="mapbox-geocoder" data-value="" data-current-location="1" data-your-location="" data-placeholder="<?php echo e(__('Enter a location ...')); ?>" data-lang="<?php echo e(get_current_language()); ?>"></div>
        <div class="map d-none"></div>
        <input type="hidden" name="lat" value="">
        <input type="hidden" name="lng" value="">
        <input type="hidden" name="address" value="">
    </div>
    <div class="form-group form-group-date">
        <label><?php echo e(__('Date')); ?></label>
        <div class="date-wrapper date date-double" data-date-format="<?php echo e(hh_date_format_moment()); ?>" data-single-click="false" data-same-date="true">
            <input type="text" class="input-hidden check-in-out-field" name="checkInOut">
            <input type="text" class="input-hidden check-in-field" name="checkIn">
            <input type="text" class="input-hidden check-out-field" name="checkOut">
            <span class="check-in-render" data-date-format="<?php echo e(hh_date_format_moment()); ?>"></span>
            <span class="divider"></span>
            <span class="check-out-render" data-date-format="<?php echo e(hh_date_format_moment()); ?>"></span>
        </div>
    </div>

    <?php if($booking_type == 'hour'): ?>
    <div class="form-group form-group-date-time">
        <label><?php echo e(__('Time')); ?></label>
        <?php
        $listTime = list_hours(15);
        ?>
        <div class="date-wrapper date-time">
            <div class="date-render check-in-render" data-time-format="<?php echo e(hh_time_format()); ?>" data-same-time="1">
                <div class="render"><?php echo e(__('Start Time')); ?></div>
                <div class="dropdown-time">
                    <?php $__currentLoopData = $listTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item" data-value="<?php echo e($key); ?>"><?php echo e($value); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <input type="hidden" name="checkInTime" value="" class="input-checkin" />
            </div>
            <span class="divider"></span>
            <div class="date-render check-out-render" data-time-format="<?php echo e(hh_time_format()); ?>">
                <div class="render"><?php echo e(__('End Time')); ?></div>
                <div class="dropdown-time">
                    <?php $__currentLoopData = $listTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item" data-value="<?php echo e($key); ?>"><?php echo e($value); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <input type="hidden" name="checkOutTime" value="" class="input-checkin" />
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php
    $minmax = get_car_min_max_price();
    $currencySymbol = current_currency('symbol');
    $currencyPos = current_currency('position');
    ?>
    <div class="form-group">
        <label><?php echo e(__('Price Range')); ?></label>
        <input type="text" name="price_filter" data-plugin="ion-range-slider" data-prefix="<?php echo e($currencyPos == 'left' ? $currencySymbol : ''); ?>" data-postfix="<?php echo e($currencyPos == 'right' ? $currencySymbol : ''); ?>" data-min="<?php echo e($minmax['min']); ?>" data-max="<?php echo e($minmax['max']); ?>" data-from="<?php echo e($minmax['min']); ?>" data-to="<?php echo e($minmax['max']); ?>" data-skin="round">
    </div>
    <div class="form-group">
        <input class="btn btn-primary w-100" type="submit" name="sm" value="<?php echo e(__('Search')); ?>">
    </div>
</form>
<?php /**PATH C:\wamp64\www\bookings\jidrive\app\Views/frontend/car/search/search-form.blade.php ENDPATH**/ ?>
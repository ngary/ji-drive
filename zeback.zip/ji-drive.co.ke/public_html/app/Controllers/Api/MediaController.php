<?php

namespace App\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MediaController extends APIController
{
	public function __construct() {

	}

	public function store(){

    }
}
